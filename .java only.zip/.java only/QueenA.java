
/**
 * Write a description of class QueenA here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class QueenA extends Queen
{
    
    public void getEffect(){}
}
