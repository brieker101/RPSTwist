
/**
 * Write a description of interface Playable here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Playable
{
    void playCard(Card card1, Card card2, Player p1, Player p2);
}
