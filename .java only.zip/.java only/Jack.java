
/**
 * Block
    Block = Keep Card, Beats Attacks
    Special Blocks: 3 of Each.
        If attack blocked + 2 life.
        If attack blocked opponent discards a card at random.
        If attack blocked put the blocked card into your hand.
 */
public class Jack extends Card
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class Jack
     */
    public Jack()
    {
        
    }

    public int playCard(Object card)
    {
        // put your code here
        return 1;
    }
}
