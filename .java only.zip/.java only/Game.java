import java.util.ArrayList;

public class Game
{
    public Game()
    {   
    }
    //Fills the deck with 3 unique versions of King, Queen, and Jack. 9 + 9 + 9 = 27
       
}
