
/**
 * Write a description of class QueenB here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class QueenB extends Queen
{

    /**
     * Constructor for objects of class QueenB
     */
    public QueenB()
    {
        // initialise instance variables
        
    }
    public void getEffect(){}
    
}
