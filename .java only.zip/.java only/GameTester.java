
/**
 * Write a description of class GameTester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GameTester
{
   public static void main(String[] args){
       Player starter = new Player("Start");
       starter.newGame();
       
       
   }
}
